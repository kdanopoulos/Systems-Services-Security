#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"simple_crypto.h"


int main(){
	demoOTP();

    demoCC();

    demoVC();
	return 0;
}